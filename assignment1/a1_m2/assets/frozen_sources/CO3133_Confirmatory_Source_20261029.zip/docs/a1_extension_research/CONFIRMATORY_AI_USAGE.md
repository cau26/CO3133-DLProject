# AI assistance in the confirmation follow-up

OpenAI Codex assisted Trần Gia Lâm on 29 October 2026 with protocol design,
implementation, software checks, preparation of the Colab packet and analysis
of stored evidence. The exact serving-model version was not recorded.

The six existing RGB checkpoints were trained in the student's earlier A100
experiments. This follow-up's prospective RGB inference was executed locally
through Codex using CPU PyTorch, after locking models, cohort rules and analysis.
It involved no new RGB training or calibration. Its saved labels/logits were
independently replayed to verify the reported numerical summaries.

The new matched Fashion-MNIST training is supplied as executable Colab code;
its completion and results are established only by the actual returned task
receipts. Synthetic software tests do not establish model performance.

Representative requests concerned unused-image evaluation, historical exposure,
paired recipe/checkpoint comparisons, atomic recovery and source/result identity.
The human authors remain responsible for understanding the implementation,
reviewing interpretations and verifying any submitted experimental claims.
